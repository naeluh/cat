##SRC##
Testing with [Ionic framework](http://ionicframework.com/).

This is a test app with Ionic. The actual files are under `src/www/` like usually in an Ionic project.

The NUI-files can be found at `src/www/nui/`. Almost stable ones will be available under top level `build/`.

