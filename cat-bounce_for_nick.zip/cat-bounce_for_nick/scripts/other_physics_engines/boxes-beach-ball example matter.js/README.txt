A Pen created at CodePen.io. You can find this one at https://codepen.io/liabru/pen/Ivxib.

 A boxes & beach balls example created with the Matter.js physics engine.

More Matter.js examples on CodePen:
http://codepen.io/collection/Fuagy/

For more info on the engine, see:
http://brm.io/matter-js/