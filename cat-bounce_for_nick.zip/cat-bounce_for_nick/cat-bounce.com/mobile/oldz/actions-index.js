(function($){

	$(document).ready(function() {

    
	
    
    setTimeout(function() {
						 
      window.location = 'mobile.html'; 
    }, 7000);

	});
		
})(jQuery);
