A Pen created at CodePen.io. You can find this one at https://codepen.io/sdras/pen/yyWLEd.

 Just playing around with matter.js and sprites.