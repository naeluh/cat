html editor
===========

Original: https://github.com/mrdoob/htmleditor

Simple editor for messing around.
